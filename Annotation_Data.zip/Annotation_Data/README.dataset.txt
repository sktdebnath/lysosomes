# Lysosome Segmentation > 2024-07-17 V7 All in train
https://universe.roboflow.com/ant-s1guf/lysosome-segmentation-nbwd0

Provided by a Roboflow user
License: CC BY 4.0

